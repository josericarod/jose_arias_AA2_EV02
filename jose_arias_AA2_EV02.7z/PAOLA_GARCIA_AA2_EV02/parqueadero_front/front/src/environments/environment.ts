
export const environment = {

  host: 'http://localhost:8080',
  production: false
};
