import { Parqueadero } from "./parqueadero";
import { Persona } from "./persona";

export class ParqueaderoPersona{
    id: number;
    parqueadero: Parqueadero;
    persona: Persona;
}