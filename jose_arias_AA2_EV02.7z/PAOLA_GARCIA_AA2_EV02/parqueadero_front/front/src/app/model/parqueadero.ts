export class Parqueadero {
    id: number;
    nombre: string;
    estado: string;
}
