export class Persona{
    id: number;
    identificacion: string;
    nombres: string;
    primerApellido: string;
    segundoApellido: string;
}